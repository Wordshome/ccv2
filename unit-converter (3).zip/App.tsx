import React, { useState } from 'react';
import Converter from './components/Converter';
import AdsensePlaceholder from './components/AdsensePlaceholder';
import StaticLinks from './components/StaticLinks';
import { CONVERSION_CATEGORIES } from './constants';
import { ConversionCategory } from './types';

function App() {
  const [activeCategory, setActiveCategory] = useState<ConversionCategory>(CONVERSION_CATEGORIES[0]);
  const [fromUnit, setFromUnit] = useState<string>(CONVERSION_CATEGORIES[0].units[0].name);
  const [toUnit, setToUnit] = useState<string>(CONVERSION_CATEGORIES[0].units[0].name);

  const handleCategoryChange = (cat: ConversionCategory) => {
    setActiveCategory(cat);
    setFromUnit(cat.units[0].name);
    setToUnit(cat.units[0].name);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleConversionLinkClick = (categoryName: string, fromUnitName: string, toUnitName:string) => {
    const category = CONVERSION_CATEGORIES.find(c => c.name === categoryName);
    if (category) {
        const fromUnitExists = category.units.some(u => u.name === fromUnitName);
        const toUnitExists = category.units.some(u => u.name === toUnitName);

        if (fromUnitExists && toUnitExists) {
            setActiveCategory(category);
            setFromUnit(fromUnitName);
            setToUnit(toUnitName);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            console.error(`Units ${fromUnitName} or ${toUnitName} not found in category ${categoryName}`);
        }
    } else {
        console.error(`Category ${categoryName} not found`);
    }
  };

  const handleCategoryLinkClick = (categoryName: string) => {
    const category = CONVERSION_CATEGORIES.find(c => c.name === categoryName);
    if (category) {
        handleCategoryChange(category);
    }
  };


  return (
    <div className="min-h-screen bg-white font-sans">
      <header className="bg-[#006633] w-full py-3">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl text-white font-bold">UnitConverters.net</h1>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-grow">
            <div className="bg-[#003399] text-white p-2 mb-4">
              Unit Converter Express Version
            </div>
            
            <div className="flex flex-wrap border-b border-gray-300 mb-px">
              {CONVERSION_CATEGORIES.map(cat => (
                <button
                  key={cat.name}
                  onClick={() => handleCategoryChange(cat)}
                  className={`py-2 px-4 -mb-px font-semibold text-sm focus:outline-none ${
                    activeCategory.name === cat.name
                      ? 'bg-[#006633] text-white'
                      : 'bg-gray-200 text-[#006633] hover:bg-gray-300'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            <Converter 
              category={activeCategory} 
              fromUnit={fromUnit}
              toUnit={toUnit}
              setFromUnit={setFromUnit}
              setToUnit={setToUnit}
            />
            <StaticLinks onConversionLinkClick={handleConversionLinkClick} onCategoryLinkClick={handleCategoryLinkClick} />
          </div>

          <AdsensePlaceholder />
        </div>
      </main>
    </div>
  );
}

export default App;
