
export interface Unit {
  name: string;
  toBase: (value: number) => number;
  fromBase: (value: number) => number;
}

export interface ConversionCategory {
  name: string;
  units: Unit[];
}
