
import { ConversionCategory } from './types';

export const CONVERSION_CATEGORIES: ConversionCategory[] = [
  {
    name: 'Length',
    units: [
      { name: 'Meter', toBase: v => v, fromBase: v => v },
      { name: 'Kilometer', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Centimeter', toBase: v => v / 100, fromBase: v => v * 100 },
      { name: 'Millimeter', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Micrometer', toBase: v => v / 1e+6, fromBase: v => v * 1e+6 },
      { name: 'Nanometer', toBase: v => v / 1e+9, fromBase: v => v * 1e+9 },
      { name: 'Mile', toBase: v => v * 1609.34, fromBase: v => v / 1609.34 },
      { name: 'Yard', toBase: v => v * 0.9144, fromBase: v => v / 0.9144 },
      { name: 'Foot', toBase: v => v * 0.3048, fromBase: v => v / 0.3048 },
      { name: 'Inch', toBase: v => v * 0.0254, fromBase: v => v / 0.0254 },
      { name: 'Light Year', toBase: v => v * 9.461e+15, fromBase: v => v / 9.461e+15 },
    ],
  },
  {
    name: 'Temperature',
    units: [
      { name: 'Celsius', toBase: v => v + 273.15, fromBase: v => v - 273.15 },
      { name: 'Fahrenheit', toBase: v => (v - 32) * 5/9 + 273.15, fromBase: v => (v - 273.15) * 9/5 + 32 },
      { name: 'Kelvin', toBase: v => v, fromBase: v => v },
    ],
  },
  {
    name: 'Area',
    units: [
      { name: 'Square Meter', toBase: v => v, fromBase: v => v },
      { name: 'Square Kilometer', toBase: v => v * 1e+6, fromBase: v => v / 1e+6 },
      { name: 'Square Centimeter', toBase: v => v / 10000, fromBase: v => v * 10000 },
      { name: 'Hectare', toBase: v => v * 10000, fromBase: v => v / 10000 },
      { name: 'Acre', toBase: v => v * 4046.86, fromBase: v => v / 4046.86 },
      { name: 'Square Mile', toBase: v => v * 2.59e+6, fromBase: v => v / 2.59e+6 },
      { name: 'Square Foot', toBase: v => v * 0.092903, fromBase: v => v / 0.092903 },
    ],
  },
  {
    name: 'Volume',
    units: [
      { name: 'Liter', toBase: v => v, fromBase: v => v },
      { name: 'Milliliter', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Cubic Meter', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'US Gallon', toBase: v => v * 3.78541, fromBase: v => v / 3.78541 },
      { name: 'US Quart', toBase: v => v * 0.946353, fromBase: v => v / 0.946353 },
      { name: 'US Pint', toBase: v => v * 0.473176, fromBase: v => v / 0.473176 },
      { name: 'US Cup', toBase: v => v * 0.24, fromBase: v => v / 0.24 },
    ],
  },
  {
    name: 'Weight',
    units: [
      { name: 'Kilogram', toBase: v => v, fromBase: v => v },
      { name: 'Gram', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Milligram', toBase: v => v / 1e+6, fromBase: v => v * 1e+6 },
      { name: 'Metric Ton', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Pound', toBase: v => v * 0.453592, fromBase: v => v / 0.453592 },
      { name: 'Ounce', toBase: v => v * 0.0283495, fromBase: v => v / 0.0283495 },
    ],
  },
  {
    name: 'Time',
    units: [
      { name: 'Second', toBase: v => v, fromBase: v => v },
      { name: 'Minute', toBase: v => v * 60, fromBase: v => v / 60 },
      { name: 'Hour', toBase: v => v * 3600, fromBase: v => v / 3600 },
      { name: 'Day', toBase: v => v * 86400, fromBase: v => v / 86400 },
      { name: 'Week', toBase: v => v * 604800, fromBase: v => v / 604800 },
      { name: 'Month', toBase: v => v * 2.628e+6, fromBase: v => v / 2.628e+6 },
      { name: 'Year', toBase: v => v * 3.154e+7, fromBase: v => v / 3.154e+7 },
    ],
  },
];
