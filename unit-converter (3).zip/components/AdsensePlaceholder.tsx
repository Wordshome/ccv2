import React from 'react';

const AdsensePlaceholder: React.FC = () => {
  return (
    <div className="w-full md:w-64 lg:w-72 flex-shrink-0" aria-label="Advertisement space">
      <div className="bg-gray-100 border border-gray-300 p-4 h-full flex items-center justify-center text-center text-gray-500 rounded-md min-h-[250px]">
        <span>Google AdSense<br />Placeholder</span>
      </div>
    </div>
  );
};

export default AdsensePlaceholder;
