import React from 'react';

// This mapping connects sidebar link text to the actual category names in constants.ts
// We are making an assumption that "Common Converters" should default to the "Length" converter.
// The other categories are not yet implemented, so they don't have a mapping.
const sidebarToCategoryMap: { [key: string]: string } = {
  'Common Converters': 'Length',
};

const sidebarLinks = [
  'Common Converters', 'Engineering Converters', 'Heat Converters', 
  'Fluids Converters', 'Light Converters', 'Electricity Converters',
  'Magnetism Converters', 'Radiology Converters', 'Common Unit Systems'
];

interface SidebarProps {
  onCategoryLinkClick: (category: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onCategoryLinkClick }) => {
  
  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, linkText: string) => {
    e.preventDefault();
    const targetCategory = sidebarToCategoryMap[linkText];
    if (targetCategory) {
      onCategoryLinkClick(targetCategory);
    }
    // If no mapping exists, the link does nothing, which is correct for unimplemented features.
  };

  return (
    <div className="w-full md:w-64 lg:w-72 flex-shrink-0">
      <div className="bg-[#006633] text-white font-bold p-2">
        All Converters
      </div>
      <div className="border border-gray-300 bg-gray-50">
        <ul>
          {sidebarLinks.map((link, index) => {
            const isClickable = !!sidebarToCategoryMap[link];
            return (
              <li key={index} className="p-2 border-b border-gray-200">
                <a 
                  href="#" 
                  onClick={(e) => handleLinkClick(e, link)}
                  className={`text-[#006633] ${isClickable ? 'hover:underline' : 'cursor-not-allowed opacity-50'}`}
                  aria-disabled={!isClickable}
                >
                  {link}
                </a>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;