
import React from 'react';

const commonConversions = [
    'cm to inches', 'kg to lbs', 'Celsius to Fahrenheit', 'mm to inches', 'meters to feet',
    'km to miles', 'cm to feet', 'grams to ounces', 'inches to feet', 'liters to gallons',
    'pounds to ounces', 'mph to kph', 'acres to square feet', 'radians to degrees', 'kw to hp',
    'meters to yards', 'mL to cups',
    'inches to cm', 'lbs to kg', 'Fahrenheit to Celsius', 'inches to mm', 'feet to meters',
    'miles to km', 'feet to cm', 'ounces to grams', 'feet to inches', 'gallons to liters',
    'ounces to pounds', 'kph to mph', 'square feet to acres', 'degrees to radians', 'hp to kw',
    'yards to meters', 'cups to mL'
];

const fullConverters = {
    'Common Converters': ['Length', 'Weight and Mass', 'Volume', 'Temperature', 'Area', 'Pressure', 'Energy', 'Volume - Dry', 'Currency'],
    'Engineering Converters': ['Velocity - Angular', 'Acceleration', 'Acceleration - Angular', 'Density', 'Specific Volume', 'Moment of Inertia', 'Moment of Force', 'Torque'],
    'Case Converter': ['Power', 'Force', 'Time', 'Speed', 'Angle', 'Fuel Consumption', 'Numbers', 'Data Storage'],
    'Electricity Converters': ['Charge', 'Linear Charge Density', 'Surface Charge Density', 'Volume Charge Density', 'Current', 'Linear Current Density', 'Surface Current Density', 'Electric Field Strength', 'Electric Potential', 'Electric Resistance', 'Electric Resistivity']
};

const unitShorthandMap: { [key: string]: { name: string, category: string } } = {
  // Length
  'cm': { name: 'Centimeter', category: 'Length' },
  'inches': { name: 'Inch', category: 'Length' },
  'meters': { name: 'Meter', category: 'Length' },
  'feet': { name: 'Foot', category: 'Length' },
  'km': { name: 'Kilometer', category: 'Length' },
  'miles': { name: 'Mile', category: 'Length' },
  'mm': { name: 'Millimeter', category: 'Length' },
  'yards': { name: 'Yard', category: 'Length' },
  // Weight
  'kg': { name: 'Kilogram', category: 'Weight' },
  'lbs': { name: 'Pound', category: 'Weight' },
  'pounds': { name: 'Pound', category: 'Weight' },
  'grams': { name: 'Gram', category: 'Weight' },
  'ounces': { name: 'Ounce', category: 'Weight' },
  // Temperature
  'celsius': { name: 'Celsius', category: 'Temperature' },
  'fahrenheit': { name: 'Fahrenheit', category: 'Temperature' },
  // Area
  'acres': { name: 'Acre', category: 'Area' },
  'square feet': { name: 'Square Foot', category: 'Area' },
  // Volume
  'liters': { name: 'Liter', category: 'Volume' },
  'gallons': { name: 'US Gallon', category: 'Volume' },
  'ml': { name: 'Milliliter', category: 'Volume' },
  'cups': { name: 'US Cup', category: 'Volume' },
};

const categoryNameMapping: { [key: string]: string } = {
    'Length': 'Length',
    'Weight and Mass': 'Weight',
    'Volume': 'Volume',
    'Temperature': 'Temperature',
    'Area': 'Area',
};

const parseConversionLink = (linkText: string): { category: string, from: string, to: string } | null => {
    const parts = linkText.toLowerCase().split(' to ');
    if (parts.length !== 2) return null;

    const fromShorthand = parts[0].trim();
    const toShorthand = parts[1].trim();

    const fromUnitInfo = unitShorthandMap[fromShorthand];
    const toUnitInfo = unitShorthandMap[toShorthand];

    if (fromUnitInfo && toUnitInfo && fromUnitInfo.category === toUnitInfo.category) {
        return {
            category: fromUnitInfo.category,
            from: fromUnitInfo.name,
            to: toUnitInfo.name,
        };
    }

    return null;
}

interface StaticLinksProps {
    onConversionLinkClick: (category: string, from: string, to: string) => void;
    onCategoryLinkClick: (category: string) => void;
}

const LinkList: React.FC<{ items: string[]; onClick: (e: React.MouseEvent<HTMLAnchorElement>, item: string) => void }> = ({ items, onClick }) => (
    <ul className="list-disc list-inside space-y-1">
        {items.map(item => (
            <li key={item}>
                <a href="#" onClick={(e) => onClick(e, item)} className="text-[#006633] hover:underline">
                    {item}
                </a>
            </li>
        ))}
    </ul>
);

const StaticLinks: React.FC<StaticLinksProps> = ({ onConversionLinkClick, onCategoryLinkClick }) => {
    const handleConversionLink = (e: React.MouseEvent<HTMLAnchorElement>, linkText: string) => {
        e.preventDefault();
        const conversion = parseConversionLink(linkText);
        if (conversion) {
            onConversionLinkClick(conversion.category, conversion.from, conversion.to);
        }
    };

    const handleCategoryLink = (e: React.MouseEvent<HTMLAnchorElement>, item: string) => {
        e.preventDefault();
        const targetCategory = categoryNameMapping[item];
        if (targetCategory) {
            onCategoryLinkClick(targetCategory);
        }
    }

    return (
        <div className="mt-8 space-y-8">
            <div>
                <h2 className="text-xl font-semibold text-[#006633] mb-3">Common Conversions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-x-8 gap-y-1">
                     <ul className="list-disc list-inside space-y-1">
                        {commonConversions.slice(0, Math.ceil(commonConversions.length / 2)).map(item => (
                            <li key={item}><a href="#" onClick={(e) => handleConversionLink(e, item)} className="text-[#006633] hover:underline">{item}</a></li>
                        ))}
                    </ul>
                    <ul className="list-disc list-inside space-y-1">
                        {commonConversions.slice(Math.ceil(commonConversions.length / 2)).map(item => (
                            <li key={item}><a href="#" onClick={(e) => handleConversionLink(e, item)} className="text-[#006633] hover:underline">{item}</a></li>
                        ))}
                    </ul>
                </div>
            </div>
            
            <div>
                <h2 className="text-xl font-semibold text-[#006633] mb-3">Unit Converters — Full Versions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
                    <div>
                        <h3 className="text-lg font-semibold text-black mb-2">Common Converters</h3>
                        <LinkList items={fullConverters['Common Converters']} onClick={handleCategoryLink} />
                        <h3 className="text-lg font-semibold text-black mt-4 mb-2">Engineering Converters</h3>
                        <LinkList items={fullConverters['Engineering Converters']} onClick={(e) => e.preventDefault()} />
                    </div>
                    <div>
                        <LinkList items={fullConverters['Case Converter']} onClick={(e) => e.preventDefault()} />
                        <h3 className="text-lg font-semibold text-black mt-4 mb-2">Electricity Converters</h3>
                        <LinkList items={fullConverters['Electricity Converters']} onClick={(e) => e.preventDefault()} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StaticLinks;
