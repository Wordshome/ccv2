
import React, { useState, useEffect } from 'react';
import { ConversionCategory, Unit } from '../types';

interface ConverterProps {
  category: ConversionCategory;
  fromUnit: string;
  setFromUnit: (unit: string) => void;
  toUnit: string;
  setToUnit: (unit: string) => void;
}

const Converter: React.FC<ConverterProps> = ({ category, fromUnit, setFromUnit, toUnit, setToUnit }) => {
  const [fromValue, setFromValue] = useState<string>('1');
  const [toValue, setToValue] = useState<string>('');
  const [lastChanged, setLastChanged] = useState<'from' | 'to'>('from');

  const getUnit = (name: string): Unit | undefined => category.units.find(u => u.name === name);

  useEffect(() => {
    setFromValue('1');
    setLastChanged('from');
  }, [category, fromUnit, toUnit]);

  useEffect(() => {
    const from = getUnit(fromUnit);
    const to = getUnit(toUnit);
    if (!from || !to) return;
    
    if (lastChanged === 'from') {
      const fromVal = parseFloat(fromValue);
      if (isNaN(fromVal)) {
        setToValue('');
        return;
      }
      const baseValue = from.toBase(fromVal);
      const convertedValue = to.fromBase(baseValue);
      setToValue(convertedValue.toPrecision(6));
    }
  }, [fromValue, fromUnit, toUnit, lastChanged, category]);

  useEffect(() => {
    const from = getUnit(fromUnit);
    const to = getUnit(toUnit);
    if (!from || !to) return;

    if (lastChanged === 'to') {
      const toVal = parseFloat(toValue);
       if (isNaN(toVal)) {
        setFromValue('');
        return;
      }
      const baseValue = to.toBase(toVal);
      const convertedValue = from.fromBase(baseValue);
      setFromValue(convertedValue.toPrecision(6));
    }
  }, [toValue, fromUnit, toUnit, lastChanged, category]);


  const handleFromValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFromValue(e.target.value);
    setLastChanged('from');
  };

  const handleToValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setToValue(e.target.value);
    setLastChanged('to');
  };
  
  return (
    <div className="border border-gray-300 p-4 w-full">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="from" className="block text-sm font-medium text-gray-700">From:</label>
          <input 
            type="number" 
            id="from"
            value={fromValue}
            onChange={handleFromValueChange}
            className="mt-1 block w-full py-2 px-3 border border-gray-500 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm" 
          />
          <select 
            value={fromUnit}
            onChange={(e) => {
              setFromUnit(e.target.value);
              setLastChanged('from');
            }}
            className="mt-2 block w-full h-40 py-2 px-3 border border-gray-500 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
            size={5}
          >
            {category.units.map(unit => (
              <option key={unit.name} value={unit.name}>{unit.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="to" className="block text-sm font-medium text-gray-700">To:</label>
           <input 
            type="number" 
            id="to"
            value={toValue}
            onChange={handleToValueChange}
            className="mt-1 block w-full py-2 px-3 border border-gray-500 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm" 
          />
          <select 
            value={toUnit}
            onChange={(e) => {
              setToUnit(e.target.value);
              setLastChanged('from');
            }}
            className="mt-2 block w-full h-40 py-2 px-3 border border-gray-500 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
            size={5}
          >
            {category.units.map(unit => (
              <option key={unit.name} value={unit.name}>{unit.name}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default Converter;
